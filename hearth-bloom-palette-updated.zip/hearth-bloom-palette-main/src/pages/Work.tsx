import { motion } from "framer-motion";
import { ExternalLink, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import MzansiMeatsPreview from "@/components/previews/MzansiMeatsPreview";
import EcommercePreview from "@/components/previews/EcommercePreview";
import NonnasPreview from "@/components/previews/NonnasPreview";
import TradesPreview from "@/components/previews/TradesPreview";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const projects = [
  {
    title: "Mzansi Meats",
    client: "Inkabi Meats",
    category: "Food & Beverage",
    description:
      "A bold, conversion-focused site for a proudly South African meat supplier. Built to communicate quality, trust, and local pride — with a clean dark aesthetic that makes the product shine.",
    services: ["Brand Identity", "Web Design", "Copywriting"],
    Preview: MzansiMeatsPreview,
    url: "https://id-preview--49c8ab60-f515-48a6-bf57-013d1f778b6a.lovable.app",
    year: "2024",
  },
  {
    title: "Retail E-Commerce",
    client: "Urban Outfitters",
    category: "E-Commerce",
    description:
      "A premium fashion e-commerce experience with intuitive browsing, clean product grids, and a minimalist checkout flow designed to reduce cart abandonment and increase conversions.",
    services: ["UI/UX Design", "E-Commerce Dev", "Performance Optimisation"],
    Preview: EcommercePreview,
    url: null,
    year: "2024",
  },
  {
    title: "Nonna's Kitchen",
    client: "Nonna's Restaurant",
    category: "Restaurant",
    description:
      "An elegant restaurant site oozing Italian warmth and authenticity. Online reservations, a full menu display, and a gallery that makes guests hungry before they even arrive.",
    services: ["Web Design", "Booking Integration", "Photography Direction"],
    Preview: NonnasPreview,
    url: "https://id-preview--463169f5-1fa0-449a-a7d1-dc1343a361a7.lovable.app",
    year: "2024",
  },
  {
    title: "ProPlumb Trades",
    client: "ProPlumb Co.",
    category: "Trades & Services",
    description:
      "A professional, high-trust website for a licensed plumbing business. Clear service listings, emergency call-to-action, and a design that builds credibility from the first click.",
    services: ["Web Design", "Local SEO Setup", "Lead Generation"],
    Preview: TradesPreview,
    url: null,
    year: "2025",
  },
];

const Work = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <Button
            variant="ghost"
            className="mb-8 font-body text-muted-foreground hover:text-foreground -ml-2"
            onClick={() => navigate("/")}
          >
            <ArrowLeft size={16} className="mr-2" />
            Back to Home
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl"
          >
            <p className="font-body text-sm font-semibold uppercase tracking-widest text-primary mb-4">
              Our Work
            </p>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-[1.1] mb-6">
              Real Websites,{" "}
              <span className="text-primary">Real Results</span>
            </h1>
            <p className="font-body text-lg text-muted-foreground leading-relaxed max-w-2xl">
              Every project starts with understanding your business. Here's how
              we've helped restaurants, retailers, and trades businesses build
              their online presence and grow.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects */}
      <section className="pb-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 space-y-32">
          {projects.map((project, i) => {
            const isEven = i % 2 === 0;
            return (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.7 }}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center ${
                  !isEven ? "lg:[direction:rtl]" : ""
                }`}
              >
                {/* Preview */}
                <div
                  className={`relative group ${!isEven ? "[direction:ltr]" : ""}`}
                >
                  <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border h-[420px] lg:h-[500px] cursor-pointer"
                    onClick={() => project.url && window.open(project.url, "_blank", "noopener,noreferrer")}
                  >
                    <div className="w-full h-full overflow-hidden">
                      <project.Preview />
                    </div>

                    {/* Hover overlay */}
                    {project.url && (
                      <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/60 transition-all duration-300 flex items-center justify-center">
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-body font-semibold text-sm px-6 py-3 rounded-lg shadow-lg">
                            View Live Site
                            <ExternalLink size={16} />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Year badge */}
                  <div className="absolute -top-4 -right-4 w-14 h-14 bg-primary rounded-full flex items-center justify-center shadow-lg">
                    <span className="font-body text-xs font-bold text-primary-foreground">
                      {project.year}
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className={`space-y-6 ${!isEven ? "[direction:ltr]" : ""}`}>
                  <div>
                    <p className="font-body text-xs font-semibold uppercase tracking-widest text-primary mb-2">
                      {project.category}
                    </p>
                    <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground mb-1">
                      {project.title}
                    </h2>
                    <p className="font-body text-sm text-muted-foreground">
                      Client: {project.client}
                    </p>
                  </div>

                  <p className="font-body text-muted-foreground leading-relaxed text-base">
                    {project.description}
                  </p>

                  <div>
                    <p className="font-body text-xs font-semibold uppercase tracking-widest text-foreground mb-3">
                      Services Delivered
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {project.services.map((s) => (
                        <span
                          key={s}
                          className="font-body text-xs font-semibold px-3 py-1.5 rounded-full bg-secondary text-foreground border border-border"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  {project.url ? (
                    <Button
                      className="font-body font-semibold"
                      onClick={() =>
                        window.open(project.url!, "_blank", "noopener,noreferrer")
                      }
                    >
                      View Live Site
                      <ExternalLink size={15} className="ml-2" />
                    </Button>
                  ) : (
                    <p className="font-body text-sm text-muted-foreground italic">
                      Live preview not available for this project.
                    </p>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 text-center">
          <motion.div
            className="max-w-2xl mx-auto space-y-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-primary-foreground">
              Want a Website Like These?
            </h2>
            <p className="font-body text-primary-foreground/80 text-base">
              Let's build something great together. Reach out and we'll get
              started.
            </p>
            <Button
              variant="secondary"
              size="lg"
              className="font-body font-bold text-base px-8"
              onClick={() => navigate("/#contact")}
            >
              Get In Touch
            </Button>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Work;
